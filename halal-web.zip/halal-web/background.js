// background.js


// TODO: initialize options on installed
// chrome.runtime.onInstalled.addListener(() => {
//   chrome.storage.sync.set({ options });
// });


